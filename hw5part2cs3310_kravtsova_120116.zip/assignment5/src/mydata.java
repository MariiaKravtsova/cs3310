/**
 * Object mydata that holds student name, course number and grade
 */
public class mydata {

    String stuName;
    int courseNumber;
    char grade;

}
